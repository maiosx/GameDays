# GameDays — Windows App

Track your daily game progress with a Discord-style `/game` command.

## Quick Start

1. Double-click **GameDays.bat**
2. GameDays opens in your browser automatically
3. Start logging: `/game Red Dead Redemption II reached Chapter III`

## Requirements

- Windows 10 or later
- Node.js (v18+) — if not installed, GameDays.bat will install it for you automatically

## How to Use

Type commands in the input bar at the bottom:

```
/game [Game Title] [what you did today]
```

**Examples:**
```
/game Elden Ring defeated Margit the Fell Omen
/game Midnight Club 3 beat Bishop in the city circuit
/game Arknights Endfield reached authority level 14
/game RDR2 completed Chapter III and did 3 bounties
```

- **Tab** to autocomplete a game name you've logged before
- **Enter** or click **LOG →** to save
- Hover a log entry to reveal the **✕ delete** button
- Click any game in the sidebar to see its heatmap calendar
- Click **📁** to see where your data file is saved

## Data

Your progress is saved to:
```
C:\Users\[You]\AppData\Roaming\GameDays\data.json
```

This is a plain JSON file — you can back it up, edit it, or move it freely.

## Running in the Background

GameDays runs as a small local server on port 57321. You can keep it running in the background and reopen it anytime at:
```
http://127.0.0.1:57321
```

To stop it, close the terminal window that opened with GameDays.bat.
