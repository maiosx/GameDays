const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');

const app = express();
const PORT = 57321;

// Data file stored in user's AppData (Windows) or home dir
const dataDir = process.env.APPDATA
  ? path.join(process.env.APPDATA, 'GameDays')
  : path.join(os.homedir(), '.gamedays');

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dataFile = path.join(dataDir, 'data.json');

function loadData() {
  try {
    if (fs.existsSync(dataFile)) return JSON.parse(fs.readFileSync(dataFile, 'utf8'));
  } catch (e) {}
  return { games: {}, entries: [] };
}

function saveData(d) {
  fs.writeFileSync(dataFile, JSON.stringify(d, null, 2));
}

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API
app.get('/api/data', (req, res) => res.json(loadData()));

app.post('/api/entry', (req, res) => {
  const { gameName, note } = req.body;
  if (!gameName || !note) return res.status(400).json({ error: 'Missing fields' });
  const d = loadData();
  const key = gameName.toLowerCase().trim();
  const COLORS = ['#e05a5a','#5a9ee0','#5ae09a','#e0c25a','#a05ae0','#e0905a','#5ae0d8','#e05aad'];
  if (!d.games[key]) {
    d.games[key] = {
      name: gameName.trim(),
      color: COLORS[Object.keys(d.games).length % COLORS.length],
      created: new Date().toISOString()
    };
  }
  const entry = { id: Date.now(), gameKey: key, note, date: new Date().toISOString() };
  d.entries.unshift(entry);
  saveData(d);
  res.json({ ok: true, entry, game: d.games[key] });
});

app.delete('/api/entry/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const d = loadData();
  d.entries = d.entries.filter(e => e.id !== id);
  // Remove orphaned games
  Object.keys(d.games).forEach(key => {
    if (!d.entries.find(e => e.gameKey === key)) delete d.games[key];
  });
  saveData(d);
  res.json({ ok: true });
});

app.get('/api/datapath', (req, res) => res.json({ path: dataFile }));

const server = http.createServer(app);

server.listen(PORT, '127.0.0.1', () => {
  console.log(`GameDays running at http://127.0.0.1:${PORT}`);
  // Open browser
  const url = `http://127.0.0.1:${PORT}`;
  const start = process.platform === 'win32' ? 'start' : process.platform === 'darwin' ? 'open' : 'xdg-open';
  require('child_process').exec(`${start} ${url}`);
});

// Keep process alive
process.on('SIGINT', () => process.exit());
