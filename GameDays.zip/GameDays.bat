@echo off
title GameDays
cd /d "%~dp0"

:: Check if Node.js is installed
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo Node.js not found. Running installer...
    powershell -ExecutionPolicy Bypass -File "%~dp0install-node.ps1"
    where node >nul 2>&1
    if %errorlevel% neq 0 (
        echo.
        echo ERROR: Node.js could not be installed automatically.
        echo Please install Node.js from https://nodejs.org and run GameDays.bat again.
        pause
        exit /b 1
    )
)

:: Install dependencies if needed
if not exist "node_modules" (
    echo Installing dependencies...
    call npm install --omit=dev >nul 2>&1
)

:: Launch the app
echo Starting GameDays...
start /b node server.js

:: Wait a moment then open browser
timeout /t 1 /nobreak >nul
start http://127.0.0.1:57321
