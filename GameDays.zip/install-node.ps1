# install-node.ps1 - Auto-installs Node.js LTS if not present
$ErrorActionPreference = "Stop"

Write-Host "Downloading Node.js LTS installer..." -ForegroundColor Cyan

$nodeUrl = "https://nodejs.org/dist/v20.11.1/node-v20.11.1-x64.msi"
$installer = "$env:TEMP\node-installer.msi"

try {
    Invoke-WebRequest -Uri $nodeUrl -OutFile $installer -UseBasicParsing
    Write-Host "Installing Node.js (this may take a moment)..." -ForegroundColor Cyan
    Start-Process msiexec.exe -ArgumentList "/i `"$installer`" /quiet /norestart" -Wait
    # Refresh PATH
    $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
    Write-Host "Node.js installed successfully." -ForegroundColor Green
} catch {
    Write-Host "Auto-install failed: $_" -ForegroundColor Red
    Write-Host "Please install Node.js manually from https://nodejs.org" -ForegroundColor Yellow
}
